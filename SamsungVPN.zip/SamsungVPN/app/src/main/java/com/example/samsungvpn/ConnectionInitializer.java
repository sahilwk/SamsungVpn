package com.example.samsungvpn;

import android.util.Pair;

import com.example.samsungvpn.TCP.TcpConnectionParams;
import com.example.samsungvpn.localVPN.Packet;
import com.example.samsungvpn.localVPN.TCB;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

public interface ConnectionInitializer {
    public Pair<TCB, SocketChannel> initializeConnection(TcpConnectionParams params) throws IOException;
}
