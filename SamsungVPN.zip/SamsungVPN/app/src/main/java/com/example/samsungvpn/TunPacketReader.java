package com.example.samsungvpn;

import android.os.ParcelFileDescriptor;
import android.util.Log;


import com.example.samsungvpn.localVPN.ByteBufferPool;
import com.example.samsungvpn.localVPN.Packet;

import java.io.FileInputStream;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.concurrent.LinkedBlockingDeque;

public class TunPacketReader implements Runnable{
    private static final String TAG = "TunPacketReader";
    ParcelFileDescriptor mInterface;
    private ByteBuffer bufferToNetwork;
    LinkedBlockingDeque<Packet>tcpDeviceToNetworkQueue;
    Packet packet;

    public TunPacketReader(ParcelFileDescriptor mInterface) {
        this.mInterface = mInterface;
    }

    @Override
    public void run() {
        Log.d(TAG, "thread started running");
        FileChannel fc=new FileInputStream(mInterface.getFileDescriptor()).getChannel();
        Log.d(TAG, "run: checking if interface was passed"+mInterface);
        bufferToNetwork=byteBuffer();

        try {
            int inPacketLength = fc.read(bufferToNetwork);
        } catch (Throwable t) {
            // buffer clean up and re-throw on purpose
            ByteBufferPool.release(bufferToNetwork);
        }

        bufferToNetwork.flip();
        try {
            packet=new Packet(bufferToNetwork);
            if(packet.isTCP()) {
                tcpDeviceToNetworkQueue.offer(packet);
                Log.d(TAG, "run:a TCP packet ");
            }
            else if(packet.isUDP())
                Log.d(TAG, "run: a udp packet");
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

    }
    
    private ByteBuffer byteBuffer(){
        return ByteBufferPool.acquire();
    }

}
