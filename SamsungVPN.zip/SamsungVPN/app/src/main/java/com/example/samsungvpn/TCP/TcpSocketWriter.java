package com.example.samsungvpn.TCP;

import android.util.Log;

import com.example.samsungvpn.localVPN.ByteBufferPool;
import com.example.samsungvpn.localVPN.Packet;
import com.example.samsungvpn.localVPN.TCB;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Deque;
import java.util.LinkedList;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingDeque;

public class TcpSocketWriter {
    private static final String TAG = "TcpSocketWriter";
    public Selector selector;
    public LinkedBlockingDeque<ByteBuffer> networkToDeviceQueue;
    private ConcurrentHashMap<TCB,Deque<PendingWriteData>> writeQueue=new ConcurrentHashMap<TCB, Deque<PendingWriteData>>(10);

    public void addToWriteQueue(PendingWriteData pendingWriteData,Boolean skipQueue,TCB tcb){
        Deque<PendingWriteData>queue=tcb.writeQueue(tcb);
        if(skipQueue)
            queue.addFirst(pendingWriteData);
        else queue.add(pendingWriteData);

    }
    public void removeFromWriteQueue(TCB tcb){
        writeQueue.remove(tcb);
    }

    public TcpSocketWriter(Selector selector, LinkedBlockingDeque<ByteBuffer> networkToDeviceQueue) {
        this.selector = selector;
        this.networkToDeviceQueue = networkToDeviceQueue;
    }

    public synchronized void writeToSocket(TCB tcb){
        Deque<PendingWriteData>writeQueue=tcb.writeQueue(tcb);
        do{
            PendingWriteData writeData=writeQueue.pollFirst();
            //put comment as to where the data is being written
            ByteBuffer payloadBuffer=writeData.payloadBuffer;
            int payloadSize=writeData.payloadSize;
            SocketChannel socket=writeData.socket;
            TcpConnectionParams connectionParams=writeData.connectionParams;

            //use VpnInterceptors to write date to socket. For now we will directly write to scoket
            int bytesWritten=safeWrite(socket,payloadBuffer);
            //comment number of bytes written
            if(payloadBuffer.remaining()==0){
                fullyWritten(tcb,writeData,connectionParams);
            }
            else{
                Log.d(TAG, "writeToSocket: partial Write");
            }
        }
        while(!writeQueue.isEmpty());
            selector.wakeup();
            try {
                tcb.channel.register(selector, SelectionKey.OP_READ,tcb);
            } catch (ClosedChannelException e) {
                e.printStackTrace();
            }
    }

    private void fullyWritten(TCB tcb, PendingWriteData writeData,TcpConnectionParams connectionParams){
        tcb.acknowledgementNumberToClient=writeData.ackNumber;
        tcb.acknowledgementNumberToServer=writeData.seqNumber;

        long seqToClient=tcb.sequenceNumberToClient;
        long ackToServer=tcb.acknowledgementNumberToServer;
        long seqAckDiff=seqToClient-ackToServer;

        ByteBuffer reponseBuffer=connectionParams.responseBuffer;

        tcb.referencePacket.updateTcpBuffer(reponseBuffer,(byte)Packet.TCPHeader.ACK,tcb.sequenceNumberToClient,tcb.acknowledgementNumberToClient,0);
        ByteBufferPool.release(writeData.payloadBuffer);
        networkToDeviceQueue.offer(reponseBuffer);

    }
    
    private int safeWrite(ByteChannel socket,ByteBuffer payloadBuffer){
        int bytesWritten=-1;
        try {
            bytesWritten= socket.write(payloadBuffer);
        } catch (IOException e) {
            ByteBufferPool.release(payloadBuffer);
            e.printStackTrace();
        }
        return bytesWritten;
    }


}
