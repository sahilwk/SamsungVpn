package com.example.samsungvpn.TCP;

import com.example.samsungvpn.localVPN.TCB;

import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

public class PendingWriteData {

    public ByteBuffer payloadBuffer;
    public SocketChannel socket;
    public TCB tcb;
    public int payloadSize;
    public TcpConnectionParams connectionParams;
    public long ackNumber;
    public long seqNumber;

    public PendingWriteData(ByteBuffer payloadBuffer, SocketChannel socket,int payloadSize, TCB tcb, TcpConnectionParams connectionParams,
                            long ackNumber,long seqNumber){
        this.payloadBuffer=payloadBuffer;
        this.socket=socket;
        this.payloadSize=payloadSize;
        this.tcb=tcb;
        this.connectionParams=connectionParams;
        this.ackNumber=ackNumber;
        this.seqNumber=seqNumber;
    }
}
