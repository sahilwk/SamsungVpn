package com.example.samsungvpn;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.logging.Logger;

public class MainActivity extends AppCompatActivity {
    String TAG="MainActivity";



    ActivityResultLauncher<Intent> startActivity=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),new ActivityResultCallback<ActivityResult>(){
        @Override
        public void onActivityResult(ActivityResult result) {
            if(result.getResultCode()==RESULT_OK) {
                Log.d(TAG, "onActivityResult: connection request should have been made");
                startService(new Intent(getApplicationContext(),TrackerBlockingService.class));
            }
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate mainActivity");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button vpn=(Button) findViewById(R.id.vpn_toggle_btn);
        vpn.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                vpn.setEnabled(false);
                Thread sThread=new Thread(){
                    @Override
                    public void run() {
                        Intent in=TrackerBlockingService.prepare(getApplicationContext());
                        if(in==null) {
                            Log.d(TAG, "run: prepare returned null intent");
                            startService(new Intent(getApplicationContext(), TrackerBlockingService.class));
                        }
                        else startActivity.launch(in);

                    }
                };
                sThread.start();


            }
        });
    }
}