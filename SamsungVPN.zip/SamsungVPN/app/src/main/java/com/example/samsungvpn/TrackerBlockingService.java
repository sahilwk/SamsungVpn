package com.example.samsungvpn;

import static androidx.core.app.ActivityCompat.startActivityForResult;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;

import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import com.example.samsungvpn.TCP.TcbCloser;
import com.example.samsungvpn.TCP.TcpConnectionInitializer;
import com.example.samsungvpn.TCP.TcpSocketWriter;
import com.example.samsungvpn.localVPN.Packet;

import java.io.IOException;
import java.nio.channels.Selector;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingDeque;

public class TrackerBlockingService extends VpnService  implements Runnable {
    private Thread uiThread;
    public Selector selector=Selector.open();
    BlockingDeque<Packet> tcpDeviceToNetworkQueue=new LinkedBlockingDeque<Packet>();
    BlockingDeque<Packet> networkToDeviceQueue=new LinkedBlockingDeque<Packet>();
    private ParcelFileDescriptor mInterface;
    private TunPacketReader tunpacketreader;
    ActivityResultLauncher activityResultLauncher;
    ExecutorService executorService;
    public TcpConnectionInitializer connectionInitializer=new TcpConnectionInitializer();
    public TcpSocketWriter tcpSocketWriter=new TcpSocketWriter(selector,networkToDeviceQueue);
    public TcbCloser tcbCloser=new TcbCloser(tcpSocketWriter);
    BlockingDeque<Packet> udpDeviceToNetwork=new LinkedBlockingDeque<Packet>();
    public static final int RESULT_OK=-1;
    String TAG="TrackerBlockingService";

    public TrackerBlockingService() throws IOException {
    }

    @Override
    public void onCreate() {
        Log.d(TAG,"in on create");

        //Intent in=prepare(this);
        //startActivity.launch(in);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG,"in onStartCommand");
        uiThread=new Thread(this);
        uiThread.start();
        return START_NOT_STICKY;
    }

    @Override
    public void run(){
        Log.d(TAG,"uiThread Running");
        if(!setup_network())
            return;

        Thread pReader=new Thread(new TunPacketReader (mInterface));
        pReader.start();

        executorService=Executors.newFixedThreadPool(4);
        executorService.submit(new TunPacketReader (mInterface));


    }


    private boolean setup_network() {
        Log.d(TAG,"setting network");
        Builder b = new Builder();
        b.addAddress("10.8.0.1", 32);
        b.addDnsServer("8.8.8.8");
        b.addRoute("0.0.0.0", 0);
        b.setMtu(1500);
        b.setBlocking(true);


        mInterface = b.establish();
        if (mInterface == null) {
            Log.d(TAG, "Failed to establish Builder interface");
            return false;
        }
        else Log.d(TAG, "setup_network: "+mInterface);
        return true;
    }


}