package com.example.samsungvpn.TCP;

public class HostnameExtractor {
}
