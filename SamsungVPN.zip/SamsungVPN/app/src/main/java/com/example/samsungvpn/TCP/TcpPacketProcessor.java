package com.example.samsungvpn.TCP;

import static com.example.samsungvpn.localVPN.Packet.TCPHeader.ACK;
import static com.example.samsungvpn.localVPN.Packet.TCPHeader.FIN;

import android.util.Log;

import com.example.samsungvpn.ConnectionInitializer;
import com.example.samsungvpn.localVPN.ByteBufferPool;
import com.example.samsungvpn.localVPN.Packet;
import com.example.samsungvpn.localVPN.TCB;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.Selector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingDeque;

public class TcpPacketProcessor implements Runnable{

    private static final String TAG = "TcpPacketProcessor";
    public Selector selector;
    public ConnectionInitializer connectionInitializer;
    public TcpSocketWriter tcpSocketWriter;
    public HostnameExtractor hostanameExtractor;
    public TcbCloser tcbCloser;
    LinkedBlockingDeque<Packet> tcpDeviceToNetworkQueue;
    LinkedBlockingDeque<ByteBuffer> networkToDeviceQueue;
    public TcpDeviceToNetwork tcpDeviceToNetwork=new TcpDeviceToNetwork(tcpDeviceToNetworkQueue,networkToDeviceQueue,selector,tcpSocketWriter,connectionInitializer,hostanameExtractor,tcbCloser);
    public TcpNetworkToDevice tcpNetworkToDevice=new TcpNetworkToDevice(tcpDeviceToNetworkQueue,networkToDeviceQueue,selector,tcpSocketWriter);

    private ExecutorService pollJobDeviceToNetwork= Executors.newSingleThreadExecutor();
    private ExecutorService pollJobNetworkToDevice= Executors.newSingleThreadExecutor();

    public TcpPacketProcessor
            (LinkedBlockingDeque<Packet>tcpDeviceToNetworkQueue,
             LinkedBlockingDeque<ByteBuffer> networkToDeviceQueue,
             ConnectionInitializer ci,
             TcpSocketWriter tsw,
             Selector selector,
             HostnameExtractor hostnameExtractor,
             TcbCloser tcbCloser
             ) throws IOException {
        this.connectionInitializer=ci;
        this.tcpSocketWriter=tsw;
        this.selector=selector;
        this.hostanameExtractor=hostnameExtractor;
        this.tcbCloser=tcbCloser;
        this.tcpDeviceToNetworkQueue=tcpDeviceToNetworkQueue;
        this.networkToDeviceQueue=networkToDeviceQueue;
    }

    @Override
    public void run() {
        pollJobDeviceToNetwork.execute(tcpDeviceToNetwork);
        pollJobNetworkToDevice.execute(tcpNetworkToDevice);
    }

    public static void updateClientState(TcbState tcbState, TCB.TCBStatus tcbStatus){
        tcbState.clientState=tcbStatus;
    }
    public static void updateServerState(TcbState tcbState,TCB.TCBStatus tcbStatus){
        tcbState.serverState=tcbStatus;
    }

    public static void sendFinToClient(LinkedBlockingDeque<ByteBuffer>networkToDeviceQueue,Packet packet,int payloadSize,
                                       TCB tcb,Boolean triggeredByServerEndOfStream){
        ByteBuffer buffer= ByteBufferPool.acquire();
        synchronized (tcb){
            long responseAck=tcb.acknowledgementNumberToClient+payloadSize;
            long responseSeq=tcb.acknowledgementNumberToServer;
            if(packet.tcpHeader.isFIN()){
                responseAck=increaseOrWraparound(responseAck,1);
            }
            tcb.referencePacket.updateTcpBuffer(buffer,(byte)(FIN|ACK),responseSeq,responseAck,0);
            if(triggeredByServerEndOfStream){
                tcb.finSequenceNumberToClient=tcb.sequenceNumberToClient;
            }
            else{
                tcb.sequenceNumberToClient=increaseOrWraparound(tcb.sequenceNumberToClient,1);
                tcb.finSequenceNumberToClient=tcb.sequenceNumberToClient;
            }
            //comment
            networkToDeviceQueue.offerFirst(buffer);
            try{
                tcb.selectionKey.cancel();
                tcb.channel.close();
            } catch (IOException e) {
                e.printStackTrace();
                Log.d(TAG, "sendFinToClient:problem closing socket connection ");
            }
        }
    }

    public static void sendAck(LinkedBlockingDeque<ByteBuffer>networkToDeviceQueue,TCB tcb,Packet packet){
        synchronized (tcb){
            int payloadSize=packet.tcpPayloadSize(true);
            tcb.acknowledgementNumberToClient=increaseOrWraparound(packet.tcpHeader.sequenceNumber,(long)payloadSize);
            tcb.sequenceNumberToClient=packet.tcpHeader.acknowledgementNumber;

            if(packet.tcpHeader.isRST()||packet.tcpHeader.isSYN()||packet.tcpHeader.isFIN()){
                tcb.acknowledgementNumberToClient=increaseOrWraparound(tcb.acknowledgementNumberToClient,1);
                Log.d(TAG, "sendAck: sending ACK fromnetwork to device, flag contains RST, SYN or FIN so incremented acknowledge number");
            }
            //comment

            ByteBuffer buffer=ByteBufferPool.acquire();
            packet.updateTcpBuffer(buffer,(byte)ACK,tcb.sequenceNumberToClient,tcb.acknowledgementNumberToClient,0);
            networkToDeviceQueue.offer(buffer);
        }
    }
    public static long increaseOrWraparound(long current,long increment){
        return (current+increment)%MAX_SEQUENCE_NUMBER;
    }
    private static long MAX_SEQUENCE_NUMBER = (long)(Math.pow(2.0,32.0) - 1);

}
