package com.example.samsungvpn.TCP;

import com.example.samsungvpn.ConnectionInitializer;
import com.example.samsungvpn.localVPN.Packet;

import java.io.IOException;
import java.nio.channels.Selector;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingDeque;

public class TcpPacketProcessor implements Runnable{

    public Selector selector;
    public ConnectionInitializer connectionInitializer;
    public TcpSocketWriter tcpSocketWriter;
    public HostnameExtractor hostanameExtractor;
    public TcbCloser tcbCloser;
    LinkedBlockingDeque<Packet> tcpDeviceToNetworkQueue;
    LinkedBlockingDeque<Packet> networkToDeviceQueue;
    private TcpDeviceToNetwork tcpDeviceToNetwork=new TcpDeviceToNetwork(tcpDeviceToNetworkQueue,networkToDeviceQueue,selector,tcpSocketWriter,connectionInitializer,hostanameExtractor,tcbCloser);
    private TcpNetworkToDevice tcpNetworkToDevice=new TcpNetworkToDevice(tcpDeviceToNetworkQueue,networkToDeviceQueue,selector,tcpSocketWriter);

    private ExecutorService pollJobDeviceToNetwork= Executors.newSingleThreadExecutor();
    private ExecutorService pollJobNetworkToDevice= Executors.newSingleThreadExecutor();

    public TcpPacketProcessor
            (LinkedBlockingDeque<Packet>tcpDeviceToNetworkQueue,
             LinkedBlockingDeque<Packet>networkToDeviceQueue,
             ConnectionInitializer ci,
             TcpSocketWriter tsw,
             Selector selector,
             HostnameExtractor hostnameExtractor,
             TcbCloser tcbCloser) throws IOException {
        this.connectionInitializer=ci;
        this.tcpSocketWriter=tsw;
        this.selector=selector;
        this.hostanameExtractor=hostnameExtractor;
        this.tcbCloser=tcbCloser;
        this.tcpDeviceToNetworkQueue=tcpDeviceToNetworkQueue;
        this.networkToDeviceQueue=networkToDeviceQueue;
    }

    @Override
    public void run() {
        pollJobDeviceToNetwork.execute(tcpDeviceToNetwork);
        pollJobNetworkToDevice.execute(tcpNetworkToDevice);
    }
}
