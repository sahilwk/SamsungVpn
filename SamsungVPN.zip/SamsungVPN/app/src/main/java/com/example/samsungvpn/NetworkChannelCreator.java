package com.example.samsungvpn;

import com.example.samsungvpn.TCP.TcpConnectionParams;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SocketChannel;

public class NetworkChannelCreator {
    public InetSocketAddress address;
    private TrackerBlockingService vpnService;



    public  NetworkChannelCreator(InetSocketAddress address){
        this.address=address;
    }

    public SocketChannel createSocketChannel() throws IOException {

        SocketChannel sc=SocketChannel.open();
        sc.configureBlocking(false);
        vpnService.protect(sc.socket());
        try{
            sc.connect(address);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sc;
    }

    public DatagramChannel createDatagramChannel() throws IOException {
        DatagramChannel dc=DatagramChannel.open();
        dc.configureBlocking(false);
        vpnService.protect(dc.socket());
        dc.socket().setBroadcast(true);
        return dc;
    }

}
