package com.example.samsungvpn.TCP;

import android.util.Log;

import com.example.samsungvpn.ConnectionInitializer;
import com.example.samsungvpn.localVPN.ByteBufferPool;
import com.example.samsungvpn.localVPN.LRUCache;
import com.example.samsungvpn.localVPN.Packet;
import com.example.samsungvpn.localVPN.TCB;

import java.io.IOException;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.channels.CancelledKeyException;
import java.nio.channels.Selector;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;

public class TcpDeviceToNetwork implements Runnable {

    private static final String TAG = "TcpDeviceToNetwork";
    private Selector selector;
    public LinkedBlockingDeque<Packet> tcpDeviceToNetworkQueue;
    public LinkedBlockingDeque<Packet> networkToDeviceQueue;
    public TcpSocketWriter tcpSocketWriter;
    public ConnectionInitializer connectionInitializer;
    public HostnameExtractor hostnameExtractor;
    public TcbCloser tcbCloser;




    public  TcpDeviceToNetwork(
            LinkedBlockingDeque<Packet>tcpDeviceToNetworkQueue,
            LinkedBlockingDeque<Packet> networkToDeviceQueue,
            Selector selector,
            TcpSocketWriter tcpSocketWriter,
            ConnectionInitializer connectionInitializer,
            HostnameExtractor hostnameExtractor,
            TcbCloser tcbCloser
    ){
        this.tcpDeviceToNetworkQueue=tcpDeviceToNetworkQueue;
        this.networkToDeviceQueue=networkToDeviceQueue;
        this.selector=selector;
        this.tcpSocketWriter=tcpSocketWriter;
        this.connectionInitializer=connectionInitializer;
        this.hostnameExtractor=hostnameExtractor;
        this.tcbCloser=tcbCloser;
    }

    @Override
    public void run() {
        while(!Thread.interrupted()){
            try{
                deviceToNetworkProcessing();
            }
            catch(IOException e){
                Log.d(TAG, "run:Failed to process TCP device-to-network pakcet");
            }
            catch (CancelledKeyException e){
                Log.d(TAG, "run:Failed to process TCP device-to-network pakcet");
            }
            catch(InterruptedException e){
                Log.d(TAG, "Thread is interrupted");
                return;
            }
        }
    }

    private void deviceToNetworkProcessing() throws InterruptedException {
        Packet packet;
        if(tcpDeviceToNetworkQueue!=null){
            packet=tcpDeviceToNetworkQueue.take();
        }
        else return;
        InetAddress destinationAddress=packet.getIpHeader().getDestinationAddress();
        int destinationPort =packet.tcpHeader.destinationPort;
        int sourcePort=packet.tcpHeader.sourcePort;

        if(packet.backingBuffer==null)
            return;

        TcpConnectionParams connectionParams=new TcpConnectionParams(destinationAddress.getHostAddress(),destinationPort,sourcePort,packet, ByteBufferPool.acquire());
        TCB tcb=TCB.getTCB(connectionParams.key());

        if(tcb==null){
            processPacketTcbNotInitialized(connectionParams);
        }
        else{
            processPacketTcbExists(connectionParams);
        }
    }

    private void processPacketTcbNotInitialized(TcpConnectionParams connectionParams){
        Packet packet=connectionParams.packet;
        int totalPacketLength= connectionParams.packet.backingBuffer.limit();

        //Log.d("New Packet. %s", "processPacketTcbNotInitialized: ");

    }



}
