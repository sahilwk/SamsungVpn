package com.example.samsungvpn.TCP;

import static com.example.samsungvpn.localVPN.TCB.TCBStatus.CLOSING;
import static com.example.samsungvpn.localVPN.TCB.TCBStatus.ESTABLISHED;
import static com.example.samsungvpn.localVPN.TCB.TCBStatus.FIN_WAIT_1;
import static com.example.samsungvpn.localVPN.TCB.TCBStatus.FIN_WAIT_2;
import static com.example.samsungvpn.localVPN.TCB.TCBStatus.LAST_ACK;
import static com.example.samsungvpn.localVPN.TCB.TCBStatus.LISTEN;
import static com.example.samsungvpn.localVPN.TCB.TCBStatus.SYN_SENT;
import static com.example.samsungvpn.localVPN.TCB.TCBStatus.TIME_WAIT;

import android.util.Log;

import com.example.samsungvpn.localVPN.Packet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TcpStateFlow {
    private static final String TAG = "TcpStateFlow";

    public static List<String> events=new ArrayList<String>();
    public static List<String> newPacket(
            String connectionKey,
            TcbState currentState,
            PacketType packetType,
            long sequenceNumberToClientInitial
    ){
        switch(currentState.serverState){
            case LISTEN:events=handlePacketInStateListen(connectionKey, currentState, packetType);
            case SYN_RECEIVED:events=handlePacketInSynReceived(connectionKey, currentState, packetType, sequenceNumberToClientInitial);
            case ESTABLISHED:events=handlePacketInEstablished(connectionKey, currentState, packetType);
            case LAST_ACK:events=handlePacketInLastAck(packetType, connectionKey, currentState);
            case FIN_WAIT_1:events=handlePacketInFinWait1(connectionKey, currentState, packetType);
            case FIN_WAIT_2:events=handlePacketInFinWait2(connectionKey, currentState, packetType);
            case CLOSING:events=handlePacketInClosing(connectionKey, currentState, packetType);
            case TIME_WAIT:events=handlePacketInTimeWait(connectionKey, packetType);
            case CLOSED:events=handlePacketInClosed(connectionKey, packetType);
            default:events=unhandledEvent(connectionKey, currentState, packetType);
        }
        return events;

    }

    public static List<String> handlePacketInTimeWait(String connectionKey,PacketType packetType){
        events.clear();
        if(packetType.isRst){
            events.add(Event.CloseConnection.toString());
        }
        else events.add(Event.SendReset.toString());
        return events;
    }

    public static List<String> handlePacketInClosed(String connectionKey, PacketType packetType){
        events.clear();
        if(packetType.isRst){
            events.add(Event.CloseConnection.toString());
        }
        else events.add(Event.SendReset.toString());
        return events;
    }
    public static List<String> handlePacketInLastAck(PacketType packetType,String connectionKey,TcbState currentState){
        events.clear();
        if(packetType.isRst){
            events.add(Event.CloseConnection.toString());
        }
        else if(isAckForOurFin(packetType,connectionKey,currentState))
            events.add(Event.CloseConnection.toString());
        else if(packetType.isAck)
            events.add(Event.ProcessPacket.toString());
        else events.add(Event.SendReset.toString());
        return events;
    }

    private static Boolean isAckForOurFin(PacketType packetType,String connectionKey,TcbState currentState){
        if (!packetType.isAck && !packetType.isFin) {
            return false;
        }

        Boolean match = isMatchingAckForOurFin(packetType);
        if (!match) {
            /*Timber.w(
                    "%s - %s, received [fin=%s, ack=%s] but mismatching numbers. Expected=%d, actual=%d",
                    connectionKey, currentState, packetType.isFin, packetType.isAck, packetType.finSequenceNumberToClient, packetType.ackNum
            )*/
        } else {
            /*Timber.v(
                    "%s - %s, received [fin=%s, ack=%s] with matching numbers. Expected=%d, actual=%d",
                    connectionKey, currentState, packetType.isFin, packetType.isAck, packetType.finSequenceNumberToClient, packetType.ackNum
            )*/
        }
        return match;
    }

    private static Boolean isMatchingAckForOurFin(PacketType packetType){
        if(packetType.finSequenceNumberToClient<0)
            return false;
        long difference=Math.abs(packetType.ackNum-packetType.finSequenceNumberToClient);
        return difference<=1;
    }

    private static List<String> handlePacketInFinWait1(String connectionKey,TcbState currentState, PacketType packetType){
        if(packetType.isRst){
            events.add(Event.CloseConnection.toString());
        }
        else if(packetType.isFin){
            events.add(Event.SendAck.toString());
            events.add("MoveServerToState "+CLOSING.toString());
        }
        else if(packetType.isAck){
            if(isAckForOurFin(packetType,connectionKey,currentState)){
                events.add("MoveServerToState "+FIN_WAIT_2.toString());
            }
            else{
                events.add(Event.ProcessPacket.toString());
                events.add("MoveServerToState "+FIN_WAIT_2.toString());
            }
        }
        else events.add(Event.SendReset.toString());
        return events;
    }

    private static List<String> handlePacketInFinWait2(String connectionKey,TcbState currentState, PacketType packetType){
        events.clear();
        if(packetType.isFin){
            events.add(Event.SendAck.toString());
            events.add("MoveServerToState "+CLOSING.toString());
            events.add("MoveClientToState "+TIME_WAIT.toString());
            events.add(Event.DelayedCloseConnection.toString());
        }
        else if(packetType.isRst){
            events.add(Event.CloseConnection.toString());
        }
        else if(packetType.hasData){
            events.add(Event.ProcessPacket.toString());
        }
        else return Collections.emptyList();
        return events;
    }
    private static List<String> handlePacketInClosing(String connectionKey,TcbState currentState, PacketType packetType){
        events.clear();
        if(packetType.hasData){
            events.add(Event.SendAck.toString());
        }
        if(packetType.isRst){
            events.add(Event.CloseConnection.toString());
        }
        else if(packetType.isAck){
            events.add("MoveClientToState "+TIME_WAIT.toString());
            events.add(Event.DelayedCloseConnection.toString());
        }
        else events.add(Event.SendReset.toString());
        return events;
    }

    private static List<String> handlePacketInStateListen(String connectionKey,TcbState currentState, PacketType packetType){
        events.clear();
        if(packetType.isRst){
            events.add(Event.CloseConnection.toString());
        }
        else if(packetType.isSyn){
            if(currentState.clientState==SYN_SENT){
                return Collections.emptyList();
            }
            events.add(Event.OpenConnection.toString());
        }
        else if(packetType.hasData)
            events.add(Event.SendAck.toString());
        else events.add(Event.SendReset.toString());
        return events;
    }

    private static List<String> socketOpeningInListenState(){
        events.add("MoveClientToState "+SYN_SENT.toString());
        events.add(Event.WaitToConnect.toString());
        return events;
    }

    private static List<String> handlePacketInSynReceived(String connectionKey,TcbState currentState, PacketType packetType,long initialSequenceNumberToClient){
        if(packetType.isRst){
            events.add(Event.CloseConnection.toString());
        }
        else if(packetType.isAck) {
            if (packetType.ackNum != initialSequenceNumberToClient + 1) {
                Log.d(TAG, "Acknowledgement numbers don't match");
            }
            events.add("MoveServerToState "+ESTABLISHED.toString());
            events.add("MoveClientToState "+ESTABLISHED.toString());
            events.add(Event.ProcessPacket.toString());
        }
        else events.add(Event.SendReset.toString());
        return  events;
    }

    private static List<String> handlePacketInEstablished(String connectionKey,TcbState currentState, PacketType packetType){
        if(packetType.isFin){
            if(packetType.hasData){
                events.add(Event.ProcessPacket.toString());
                events.add(Event.SendFin.toString());
            }
            else events.add(Event.SendFin.toString());
            events.add("MoveClientToState "+FIN_WAIT_1.toString());
            events.add("MoveServerToState "+LAST_ACK.toString());
        }
        else if(packetType.isRst){
            events.add(Event.CloseConnection.toString());
        }
        else if(packetType.isAck){
            events.add(Event.ProcessPacket.toString());
        }
        else events.add(Event.SendReset.toString());
        return  events;
    }
    public static List<String> socketOpening(TcbState currentState){
        events.clear();
        if(currentState.serverState==LISTEN){
            events=socketOpeningInListenState();
        }
        else return Collections.emptyList();
        return events;
    }
    public static List<String> socketEndOfStream(){
        List<String>l1=new ArrayList<String>();
        List<String>l2=new ArrayList<String>();
        l1.add("MoveServerToState "+FIN_WAIT_1.toString());
        l1.add("MoveClientToState "+LAST_ACK.toString());
        l2.addAll(l1);
        return l2;
    }

    private static List<String> unhandledEvent(String connectionKey,TcbState currentState, PacketType packetType){
        return Collections.emptyList();
    }
    public enum Event{
        OpenConnection,
        WaitToConnect,
        ProcessPacket,
        SendAck,
        SendFin,
        SendFinWithData,
        SendSynAck,
        SendReset,
        CloseConnection,
        DelayedCloseConnection;

    }








}
