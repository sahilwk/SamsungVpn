package com.example.samsungvpn;

import android.os.ParcelFileDescriptor;
import android.util.Log;

import com.example.samsungvpn.localVPN.ByteBufferPool;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.concurrent.LinkedBlockingDeque;

public class TunPacketWriter implements Runnable{


    LinkedBlockingDeque<ByteBuffer> networkToDeviceQueue;
    private static final String TAG = "TunPacketWriter";
    private ParcelFileDescriptor mInterface;
    private Boolean running=true;

    public TunPacketWriter(ParcelFileDescriptor mInterface,LinkedBlockingDeque<ByteBuffer> networkToDeviceQueue) {
        this.networkToDeviceQueue = networkToDeviceQueue;
        this.mInterface = mInterface;
    }



    @Override
    public void run() {
        running=true;

        FileChannel fc=new FileInputStream(mInterface.getFileDescriptor()).getChannel();
        while(running && !Thread.interrupted()){
            try{
                executeWriteLoop(fc);
            } catch (InterruptedException e) {
                running =false;
                Log.d(TAG, "run: Thread interrupted");
                e.printStackTrace();
            }
        }
    }

    private void executeWriteLoop(FileChannel vpnOutput) throws InterruptedException {
        ByteBuffer bufferFromNetwork=networkToDeviceQueue.take();
        try{
            bufferFromNetwork.flip();

            while (bufferFromNetwork.hasRemaining()) {
                int bytesWrittenToVpn = vpnOutput.write(bufferFromNetwork);
                if (bytesWrittenToVpn == 0) {
                    Log.d(TAG, "executeWriteLoop: Failed to write any bytes to TUN");
                } else {
                    Log.d(TAG, "executeWriteLoop:wrote ");
                }
            }
        } catch (IOException e) {
            //Timber.w(e, "Failed writing to the TUN")
            bufferFromNetwork.rewind();
            //Timber.d("Failed writing to the TUN. Buffer: %s", bufferFromNetwork.toByteString().hex())
        }
        finally {
            ByteBufferPool.release(bufferFromNetwork);
        }
    }

    public void stop(){
        running=false;
    }
}
