package com.example.samsungvpn.TCP;

import com.example.samsungvpn.localVPN.Packet;

public class PacketType {

        public Boolean isSyn=false;
        public Boolean isAck=false;
        public Boolean isFin=false;
        public Boolean isRst=false;
        public Boolean hasData=false;
        public long ackNum=0;
        public long finSequenceNumberToClient =-1;

        public PacketType(Packet packet,long finSequenceNumberToClient){
                this.hasData= packet.tcpPayloadSize(true) > 0;
                Packet.TCPHeader tcpHeader= packet.tcpHeader;
                this.isSyn=packet.tcpHeader.isSYN();
                this.isAck=packet.tcpHeader.isACK();
                this.isFin=packet.tcpHeader.isFIN();
                this.isRst=packet.tcpHeader.isRST();
                this.ackNum=tcpHeader.acknowledgementNumber;
                this.finSequenceNumberToClient=finSequenceNumberToClient;
        }




}
