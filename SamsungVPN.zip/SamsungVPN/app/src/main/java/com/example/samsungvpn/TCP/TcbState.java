package com.example.samsungvpn.TCP;

import com.example.samsungvpn.localVPN.TCB;

public class TcbState {

    public TCB.TCBStatus clientState= TCB.TCBStatus.CLOSED;
    public TCB.TCBStatus serverState= TCB.TCBStatus.LISTEN;

    @Override
    public String toString() {
        return "TcbState{" +
                "clientState=" + clientState +
                ", serverState=" + serverState +
                '}';
    }
}
