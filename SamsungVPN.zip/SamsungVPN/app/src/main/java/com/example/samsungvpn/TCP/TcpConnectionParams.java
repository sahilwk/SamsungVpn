package com.example.samsungvpn.TCP;

import com.example.samsungvpn.localVPN.ByteBufferPool;
import com.example.samsungvpn.localVPN.Packet;
import com.example.samsungvpn.localVPN.TCB;

import java.nio.ByteBuffer;

public class TcpConnectionParams {
    public String destinationAddress;
    public int destinationPort;
    public int sourcePort;
    public Packet packet;
    public ByteBuffer responseBuffer;

    public TcpConnectionParams(String destinationAddress, int destinationPort, int sourcePort,
                                     Packet packet, ByteBuffer responseBuffer){
        this.destinationAddress=destinationAddress;
        this.destinationPort=destinationPort;
        this.packet=packet;
        this.responseBuffer=responseBuffer;
    }

    public String key(){
        String k=""+ destinationAddress+":"+destinationPort+":"+sourcePort;
        return k;
    }
    public void close(){
        ByteBufferPool.release(responseBuffer);
        ByteBufferPool.release(packet.backingBuffer);
    }
    public TCB tcb(){
        return TCB.getTCB(key());
    }
    public TCB tcbOrClose(){
        TCB tcb=tcb();
        if(tcb==null)
            close();
        return tcb;
    }

}
