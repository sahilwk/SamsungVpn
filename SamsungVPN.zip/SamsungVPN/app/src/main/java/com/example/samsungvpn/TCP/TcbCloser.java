package com.example.samsungvpn.TCP;

import android.util.Log;

import com.example.samsungvpn.localVPN.ByteBufferPool;
import com.example.samsungvpn.localVPN.Packet;
import com.example.samsungvpn.localVPN.TCB;

import java.nio.ByteBuffer;
import java.util.concurrent.LinkedBlockingDeque;

public class TcbCloser {
    //TO-DO: check if the same tcpSocketWriter object is passed to all related methods
    private static final String TAG = "TcbCloser";
    private TcpSocketWriter tcpSocketWriter;

    public TcbCloser(TcpSocketWriter tcpSocketWriter){
        this.tcpSocketWriter=tcpSocketWriter;
    }

    public void closeConnection(TCB tcb){
        Log.d(TAG, "closeConnection:Closing TCB connection");
        tcpSocketWriter.removeFromWriteQueue(tcb);
        tcb.close();
    }

    synchronized public void sendResetPacket(TcpConnectionParams connectionParams, LinkedBlockingDeque<ByteBuffer>networkToDeviceQueue,
                                                    int payloadSize,Boolean isFIN){
        ByteBuffer buffer= ByteBufferPool.acquire();
        TCB tcb=connectionParams.tcbOrClose();

        long responseAck=tcb.acknowledgementNumberToClient+payloadSize;
        long responseSeq=tcb.acknowledgementNumberToServer;

        if(isFIN){
            responseAck=TcpPacketProcessor.increaseOrWraparound(responseAck,1);
        }
        synchronized (this) {
            tcb.referencePacket.updateTcpBuffer(buffer, (byte) (Packet.TCPHeader.RST | Packet.TCPHeader.ACK), responseSeq, responseAck, 0);
        }
        networkToDeviceQueue.offerFirst(buffer);
        closeConnection(tcb);
        connectionParams.close();
    }


}
