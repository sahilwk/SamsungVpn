package com.example.samsungvpn.TCP;

import static com.example.samsungvpn.localVPN.Packet.TCPHeader.ACK;
import static com.example.samsungvpn.localVPN.Packet.TCPHeader.SYN;

import android.util.Log;
import android.util.Pair;

import com.example.samsungvpn.ConnectionInitializer;
import com.example.samsungvpn.localVPN.ByteBufferPool;
import com.example.samsungvpn.localVPN.Packet;
import com.example.samsungvpn.localVPN.TCB;

import java.io.IOException;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.channels.CancelledKeyException;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingDeque;

public class TcpDeviceToNetwork implements Runnable {

    private static final String TAG = "TcpDeviceToNetwork";
    private Selector selector;
    public LinkedBlockingDeque<Packet> tcpDeviceToNetworkQueue;
    public LinkedBlockingDeque<ByteBuffer> networkToDeviceQueue;
    public TcpSocketWriter tcpSocketWriter;
    public ConnectionInitializer connectionInitializer;
    public HostnameExtractor hostnameExtractor;
    public TcbCloser tcbCloser;
    public TcbState tcbState;



    public  TcpDeviceToNetwork(
            LinkedBlockingDeque<Packet>tcpDeviceToNetworkQueue,
            LinkedBlockingDeque<ByteBuffer> networkToDeviceQueue,
            Selector selector,
            TcpSocketWriter tcpSocketWriter,
            ConnectionInitializer connectionInitializer,
            HostnameExtractor hostnameExtractor,
            TcbCloser tcbCloser
    ){
        this.tcpDeviceToNetworkQueue=tcpDeviceToNetworkQueue;
        this.networkToDeviceQueue=networkToDeviceQueue;
        this.selector=selector;
        this.tcpSocketWriter=tcpSocketWriter;
        this.connectionInitializer=connectionInitializer;
        this.hostnameExtractor=hostnameExtractor;
        this.tcbCloser=tcbCloser;
    }



    @Override
    public void run() {
        while(!Thread.interrupted()){
            try{
                deviceToNetworkProcessing();
            } catch (CancelledKeyException e){
                Log.d(TAG, "run:Failed to process TCP device-to-network pakcet");
            }
            catch(InterruptedException e){
                Log.d(TAG, "Thread is interrupted");
                return;
            }
        }
    }

    private void deviceToNetworkProcessing() throws InterruptedException {
        Packet packet;
        if(tcpDeviceToNetworkQueue!=null){
            packet=tcpDeviceToNetworkQueue.take();
        }
        else return;
        InetAddress destinationAddress=packet.getIpHeader().getDestinationAddress();
        int destinationPort =packet.tcpHeader.destinationPort;
        int sourcePort=packet.tcpHeader.sourcePort;

        if(packet.backingBuffer==null)
            return;

        TcpConnectionParams connectionParams=new TcpConnectionParams(destinationAddress.getHostAddress(),destinationPort,sourcePort,packet, ByteBufferPool.acquire());
        TCB tcb=TCB.getTCB(connectionParams.key());

        if(tcb==null){
            processPacketTcbNotInitialized(connectionParams);
        }
        else{
            processPacketTcbExists(connectionParams);
        }
    }

    private void processPacketTcbNotInitialized(TcpConnectionParams connectionParams){
        Packet packet=connectionParams.packet;
        int totalPacketLength= connectionParams.packet.backingBuffer.limit();

        //Log.d("New Packet. %s", "processPacketTcbNotInitialized: ");
        PacketType pt=new PacketType(packet,-1);
        TcbState tcbState=new TcbState();
        List<String> events=TcpStateFlow.newPacket(connectionParams.key(),tcbState,pt,-1);
        for(String event:events){
            switch(event){
                case "OpenConnection": openConnection(connectionParams);
                case "SendAck": synchronized (connectionParams.responseBuffer){
                    connectionParams.packet.updateTcpBuffer(connectionParams.responseBuffer, (byte)Packet.TCPHeader.ACK,
                            0,connectionParams.packet.tcpHeader.sequenceNumber +1,0);
                    networkToDeviceQueue.offer(connectionParams.responseBuffer);
                }
                case "SendReset": synchronized (connectionParams.responseBuffer){
                    connectionParams.packet.updateTcpBuffer(connectionParams.responseBuffer, (byte)Packet.TCPHeader.RST,
                            0,connectionParams.packet.tcpHeader.sequenceNumber +1,0);
                    networkToDeviceQueue.offer(connectionParams.responseBuffer);
                }
                default:
                    Log.d(TAG, "processPacketTcbNotInitialized: No connection open");
            }
        }
    }

    private void processPacketTcbExists(TcpConnectionParams connectionParams){
        Packet packet=connectionParams.packet;
        ByteBuffer payloadBuffer=connectionParams.packet.backingBuffer;
        int totalPacketLength=payloadBuffer.limit();
        TCB tcb=connectionParams.tcbOrClose();
        //comment
        if(packet.tcpHeader.isACK()){
            tcb.acknowledgementNumberToServer=packet.tcpHeader.acknowledgementNumber;
        }
        PacketType pt=new PacketType(packet,tcb.finSequenceNumberToClient);
        List<String>events=TcpStateFlow.newPacket(connectionParams.key(),tcb.tcbState,pt,tcb.sequenceNumberToClientInitial);
        //comment
        for(String event:events){
            String[] splitted=event.split(" ");
            if(splitted[0]=="MoveClientToState"){
                TcpPacketProcessor.updateClientState(tcbState, TCB.TCBStatus.valueOf(splitted[1]));
            }
            else if(splitted[0]=="MoveServerToState"){
                TcpPacketProcessor.updateServerState(tcbState, TCB.TCBStatus.valueOf(splitted[1]));
            }
            switch(event){
                case "ProcessPacket": processPacket(connectionParams);
                case "SendFin": TcpPacketProcessor.sendFinToClient(networkToDeviceQueue,packet,packet.tcpPayloadSize(true),
                        tcb,false);
                case "SendFinWithData": TcpPacketProcessor.sendFinToClient(networkToDeviceQueue,packet,0,tcb,false);
                case "CloseConnection": closeConnection(connectionParams);
                case "SendReset":tcbCloser.sendResetPacket(connectionParams,networkToDeviceQueue,packet.tcpPayloadSize(true),packet.tcpHeader.isFIN());
                case "DelayedCloseConnection":
                    Executors.newSingleThreadExecutor().execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(3000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        closeConnection(connectionParams);
                    }
                });
                case "SendAck": TcpPacketProcessor.sendAck(networkToDeviceQueue,tcb,packet);
                default:
                    Log.d(TAG, "processPacketTcbExists: Unknow event for how to process device-to-network packet");
            }
        }
    }

    private void closeConnection(TcpConnectionParams connectionParams){
        TCB getTcb=TCB.getTCB(connectionParams.key());
        if(getTcb!=null)
            tcbCloser.closeConnection(getTcb);
        connectionParams.close();
    }

    private void processPacket(TcpConnectionParams connectionParams){
        Packet packet=connectionParams.packet;
        ByteBuffer payloadBuffer=packet.backingBuffer;

        TCB tcb=connectionParams.tcbOrClose();
        if(tcb==null)
            return;
        else{
            synchronized (tcb){
                int payloadSize=payloadBuffer.limit()-payloadBuffer.position();
                if(payloadSize==0){
                    Log.d(TAG, "processPacket: ");
                    ByteBufferPool.release(payloadBuffer);
                    return;
                }
                Boolean isLocalAddress=packet.getIpHeader().getDestinationAddress().isSiteLocalAddress();
                //TO-DO: implement determinerequestingApp
                //TO-DO: implement determineRequestingApp
                //TO-DO: implement determineHostName
                //TO-DO: implement determineIfTracker

                //add comment about how many bytes are being sent to which host

                if(!tcb.waitingForNetworkData){
                    Log.d(TAG, "processPacket: registering for OP_READ");
                    selector.wakeup();
                    tcb.selectionKey.interestOps(SelectionKey.OP_READ);
                    tcb.waitingForNetworkData=true;
                }

                try{
                    long seqNumber=packet.tcpHeader.acknowledgementNumber;
                    long ackNumber=TcpPacketProcessor.increaseOrWraparound(packet.tcpHeader.sequenceNumber,(long)payloadSize);
                    if(packet.tcpHeader.isFIN()||packet.tcpHeader.isRST()||packet.tcpHeader.isSYN()){
                        ackNumber=TcpPacketProcessor.increaseOrWraparound(ackNumber,1);
                    }
                    tcb.acknowledgementNumberToClient=ackNumber;

                    selector.wakeup();
                    tcb.channel.register(selector,SelectionKey.OP_WRITE,tcb);

                    PendingWriteData writeData=new PendingWriteData(payloadBuffer,tcb.channel,payloadSize,tcb,connectionParams,ackNumber,seqNumber);
                    tcpSocketWriter.addToWriteQueue(writeData,false,tcb);
                } catch (ClosedChannelException e) {
                    int bytesUnwritten=payloadBuffer.remaining();
                    int bytesWritten=payloadSize-bytesUnwritten;
                    Log.d(TAG, "processPacket: Network Write Error");
                    tcbCloser.sendResetPacket(connectionParams,networkToDeviceQueue,bytesWritten,packet.tcpHeader.isFIN());
                    return;
                }
            }
        }
    }



    private void openConnection(TcpConnectionParams params){
        //comment
        Pair<TCB, SocketChannel> tcbChannel;
        try {
            tcbChannel=ConnectionInitializer.initializeConnection(params,networkToDeviceQueue);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
        TCB temp=tcbChannel.first;
        SocketChannel channel=tcbChannel.second;
        List<String> events=TcpStateFlow.socketOpening(temp.tcbState);
        for(String event:events){
            String[] splitted=event.split(" ");
            if(splitted[0]=="MoveClientToState"){
                TcpPacketProcessor.updateClientState(tcbState, TCB.TCBStatus.valueOf(splitted[1]));
            }
            else if(splitted[0]=="MoveServerToState"){
                TcpPacketProcessor.updateServerState(tcbState, TCB.TCBStatus.valueOf(splitted[1]));
            }

            switch(event){
                case "SendSynAck": synchronized (temp){
                    params.packet.updateTcpBuffer(params.responseBuffer, (byte) (SYN|ACK),temp.sequenceNumberToClient,temp.acknowledgementNumberToClient,0);
                    temp.sequenceNumberToClient++;
                    networkToDeviceQueue.offer(params.responseBuffer);
                }
                case "WaitToConnect": selector.wakeup();
                    try {
                        temp.selectionKey=channel.register(selector, SelectionKey.OP_CONNECT,temp);
                    } catch (ClosedChannelException e) {
                        e.printStackTrace();
                    }
                default:
                    Log.d(TAG, "openConnection: unexpected action");
            }
        }

    }









}
