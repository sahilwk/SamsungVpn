package com.example.samsungvpn.TCP;

import android.util.Log;

import com.example.samsungvpn.localVPN.ByteBufferPool;
import com.example.samsungvpn.localVPN.Packet;
import com.example.samsungvpn.localVPN.TCB;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.CancelledKeyException;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;

public class TcpNetworkToDevice implements Runnable{

    public LinkedBlockingDeque<Packet> tcpDeviceToNetworkQueue;
    public LinkedBlockingDeque<ByteBuffer> networkToDeviceQueue;
    public Selector selector;
    public TcpSocketWriter tcpSocketWriter;
    public TcbCloser tcbCloser;
    public TcbState tcbState;

    private static final String TAG = "TcpNetworkToDevice";
    @Override
    public void run() {
        while(!Thread.interrupted()){
            try{
                networkToDeviceProcessing();
            }
            catch (CancelledKeyException e){
                Log.d(TAG, "run: Failed to process TCp nwtwork-to-device packet");
            }
            catch (InterruptedException e){
                Log.d(TAG, "run: Thread is interrupted");
            }
        }
    }
    public TcpNetworkToDevice(LinkedBlockingDeque<Packet> tcpDeviceToNetworkQueue,LinkedBlockingDeque<ByteBuffer> networkToDeviceQueue,
                              Selector selector,TcpSocketWriter tcpSocketWriter){
        this.tcpDeviceToNetworkQueue=tcpDeviceToNetworkQueue;
        this.networkToDeviceQueue=networkToDeviceQueue;
        this.selector=selector;
        this.tcpSocketWriter=tcpSocketWriter;
    }

    private void networkToDeviceProcessing() throws InterruptedException {
        int channelsReady=-1;
        try {
            channelsReady=selector.select();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        if(channelsReady==0){
            Thread.sleep(10);
            return;
        }
        Set<SelectionKey> selectedKeys = selector.selectedKeys();
        Iterator<SelectionKey> keyIterator = selectedKeys.iterator();
        while(keyIterator.hasNext()){
            SelectionKey key = keyIterator.next();
            Thread t=new Thread(new Runnable() {
                @Override
                public void run() {
                    if (key.isValid() && key.isReadable()) {
                        processRead(key);
                    }
                    else if (key.isValid() && key.isConnectable()) {
                        try {
                            processConnect(key);
                        } catch (ClosedChannelException e) {
                            e.printStackTrace();
                        }
                    }
                    else if (key.isValid() && key.isWritable()) {
                        processWrite(key);
                    }
                }
            });
            t.start();
        }
    }

    private void processWrite(SelectionKey Key){
        TCB tcb=(TCB)Key.attachment();
        tcpSocketWriter.writeToSocket(tcb);
    }

    private void processRead(SelectionKey Key){
        ByteBuffer receiveBuffer= ByteBufferPool.acquire();
        TCB tcb=(TCB)Key.attachment();

        synchronized (tcb){
            Packet packet=tcb.referencePacket;
            receiveBuffer.position(totalHeaderSize(packet));

            SocketChannel channel= (SocketChannel) Key.channel();
            try{
                int readBytes=channel.read(receiveBuffer);

                if(readBytes==-1){//we consider if readBytes==-1 then endOfStream
                    handleEndOfStream(tcb,packet,Key);
                    ByteBufferPool.release(receiveBuffer);
                    return;
                }
                else{
                    sendToNetworkToDeviceQueue(packet,receiveBuffer,tcb,readBytes);
                }
            }
            catch (IOException e){
                ByteBufferPool.release(receiveBuffer);
                sendReset(packet,tcb);
            }
        }
    }
    private void sendReset(Packet packet,TCB tcb){
        ByteBuffer buffer = ByteBufferPool.acquire();
        packet.updateTcpBuffer(
                buffer,
                (byte)(Packet.TCPHeader.RST|Packet.TCPHeader.ACK),
                tcb.sequenceNumberToClient,
                tcb.acknowledgementNumberToClient,
                0
        );
        tcb.sequenceNumberToClient++;
        offerToNetworkToDeviceQueue(buffer, tcb, packet);

        tcbCloser.closeConnection(tcb);
    }

    private void sendToNetworkToDeviceQueue(Packet packet,ByteBuffer receiveBuffer,TCB tcb,int readBytes){
        packet.updateTcpBuffer(receiveBuffer,(byte)(Packet.TCPHeader.PSH|Packet.TCPHeader.ACK),tcb.sequenceNumberToClient,tcb.acknowledgementNumberToClient,readBytes);
        tcb.sequenceNumberToClient+=readBytes;
        receiveBuffer.position(totalHeaderSize(packet));
        offerToNetworkToDeviceQueue(receiveBuffer,tcb,packet);
    }
    private void offerToNetworkToDeviceQueue(ByteBuffer buffer, TCB tcb,Packet packet){
        //log packet details
        networkToDeviceQueue.offer(buffer);
    }

    private void handleEndOfStream(TCB tcb,Packet packet,SelectionKey Key){
        //clog tcb ipAndPort data etc
        Key.cancel();
        List<String> events=TcpStateFlow.socketEndOfStream();
        for(String event:events){
            //for now we can see that socketEndOfStream only returns sendDelayedFin as an event, we will include other events later
            /*  for(String event:events){
                    String[] splitted=event.split(" ");
                    if(splitted[0]=="MoveClientToState"){
                        TcpPacketProcessor.updateClientState(tcbState, TCB.TCBStatus.valueOf(splitted[1]));
                    }
                    else if(splitted[0]=="MoveServerToState"){
                        TcpPacketProcessor.updateServerState(tcbState, TCB.TCBStatus.valueOf(splitted[1]));
                    }
                    case "SendFin":  TcpPacketProcessor.sendFinToClient(networkToDeviceQueue,packet,packet.tcpPayloadSize(true),
                        tcb,false);
                    case "SendReset": tcbCloser.sendResetPacket(connectionParams,networkToDeviceQueue,packet.tcpPayloadSize(true),packet.tcpHeader.isFIN());
                    */
             if(event=="SendDelayedFin"){
                 Thread t1=new Thread(new Runnable() {
                     @Override
                     public void run() {
                         try {
                             Thread.sleep(100);
                         } catch (InterruptedException e) {
                             e.printStackTrace();
                         }
                         TcpPacketProcessor.sendFinToClient(networkToDeviceQueue,packet,packet.tcpPayloadSize(true),
                                 tcb,false);
                         String[] splitted=event.split(" ");
                         if(splitted[0]=="MoveClientToState"){
                             TcpPacketProcessor.updateClientState(tcb.tcbState, TCB.TCBStatus.valueOf(splitted[1]));
                         }
                         else if(splitted[0]=="MoveServerToState"){
                             TcpPacketProcessor.updateServerState(tcb.tcbState, TCB.TCBStatus.valueOf(splitted[1]));
                         }
                     }
                 });
             }
        }
    }
    private void processConnect(SelectionKey Key) throws ClosedChannelException {
        Log.d(TAG, "processConnect: got next network to device packet");
        TCB tcb=(TCB)Key.attachment();
        Packet packet=tcb.referencePacket;
        ByteBuffer responseBuffer=ByteBufferPool.acquire();
        try {
            if (tcb.channel.finishConnect()) {
                TcpPacketProcessor.updateClientState(tcb.tcbState, TCB.TCBStatus.SYN_RECEIVED);
                TcpPacketProcessor.updateServerState(tcb.tcbState, TCB.TCBStatus.SYN_SENT);
                packet.updateTcpBuffer(responseBuffer, (byte) (Packet.TCPHeader.ACK | Packet.TCPHeader.SYN), tcb.sequenceNumberToClient, tcb.acknowledgementNumberToClient, 0);
                offerToNetworkToDeviceQueue(responseBuffer, tcb, packet);
                tcb.sequenceNumberToClient++;
                tcb.channel.register(selector, 0);
            } else {
                ByteBufferPool.release(responseBuffer);
                tcb.channel.register(selector, SelectionKey.OP_CONNECT, tcb);
            }
        }
        catch (IOException e) {
            responseBuffer.clear();
            packet.updateTcpBuffer(responseBuffer,(byte)Packet.TCPHeader.RST,0,tcb.acknowledgementNumberToClient,0);
            offerToNetworkToDeviceQueue(responseBuffer,tcb,packet);
            tcbCloser.closeConnection(tcb);
            e.printStackTrace();
        }

    }


    private int totalHeaderSize(Packet packet){
        if(packet.isTCP())
            return packet.getIpHeader().getHeaderLength()+Packet.TCP_HEADER_SIZE;
        else if(packet.isUDP())
            return packet.getIpHeader().getHeaderLength()+Packet.UDP_HEADER_SIZE;
        else return -1;
    }



}
