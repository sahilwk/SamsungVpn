package com.example.samsungvpn;

import android.util.Log;
import android.util.Pair;

import com.example.samsungvpn.TCP.TcpConnectionParams;
import com.example.samsungvpn.localVPN.Packet;
import com.example.samsungvpn.localVPN.TCB;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadLocalRandom;

public interface ConnectionInitializer {
    public static final String TAG = "ConnectionInitializer";
    public static Pair<TCB, SocketChannel> initializeConnection(TcpConnectionParams params, LinkedBlockingDeque<ByteBuffer>networkToDeviceQueue) throws IOException{
        Pair<TCB, SocketChannel> p;
        String key=params.key();
        Packet.TCPHeader header=params.packet.tcpHeader;
        NetworkChannelCreator nc = new NetworkChannelCreator(new InetSocketAddress(params.destinationAddress, params.destinationPort));
        if(header.isSYN()) {
            SocketChannel channel=nc.createSocketChannel();
            Long sequenceNumberToClient= ThreadLocalRandom.current().nextLong(Short.MAX_VALUE+1);
            Long sequenceToServer=header.sequenceNumber;
            Long ackNumberToClient=header.sequenceNumber+1;
            Long ackNumberToServer=header.acknowledgementNumber;

            TCB tcb=new TCB(key, sequenceNumberToClient, sequenceToServer, ackNumberToClient, ackNumberToServer, channel, params.packet);
            TCB.putTCB(params.key(),tcb);
            p=new Pair<TCB, SocketChannel>(tcb,channel);

            return p;
        }
        else{
            Log.d(TAG, "initializeConnection:Trying to initialize a connection but is not a SYN packet; sending RST ");
            params.packet.updateTcpBuffer(params.responseBuffer,
                    (byte)Packet.TCPHeader.RST,
                    0,
                    params.packet.tcpHeader.sequenceNumber + 1,
                    params.packet.tcpPayloadSize(true)
            );
            networkToDeviceQueue.offer(params.responseBuffer);
            return null;
        }
    }
}
